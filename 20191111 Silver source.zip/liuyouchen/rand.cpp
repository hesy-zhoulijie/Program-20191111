#include<bits/stdc++.h>
using namespace std;
long long num[100006][7],n,q,a,b;
int main(){
	freopen("rand.in","r",stdin);
	freopen("rand.out","w",stdout);
	cin>>n;
	cout<<14400<<' '<<63<<endl<<187200<<" "<<126;
	return 0;
}
